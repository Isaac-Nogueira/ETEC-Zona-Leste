package com.example.appsqlite

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.appsqlite.ui.theme.AppSQLiteTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        enableEdgeToEdge()

        // Define o conteúdo visual da Activity usando Jetpack Compose
        setContent {
            AppSQLiteTheme {
                // Scaffold fornece estrutura básica com padding correto para
                // barras de sistema (status bar, navigation bar)
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    TelaCadastro(modifier = Modifier.padding(innerPadding))
                }
            }
        }
    }
}

/**
 * Tela principal de cadastro.
 * Contém campos de nome e idade, botão de cadastrar e lista de registros.
 */
@Composable
fun TelaCadastro(modifier: Modifier = Modifier) {
    // Obtém o Context atual (necessário para Toast e DatabaseHelper)
    val context = LocalContext.current

    // Instância do helper que gerencia o banco SQLite
    val dbHelper = remember { DatabaseHelper(context) }

    // Estados reativos dos campos de texto – qualquer alteração redispara a composição
    var nome  by remember { mutableStateOf("") }
    var idade by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }

    // Estado reativo da lista de usuários exibida abaixo do formulário
    var usuarios by remember { mutableStateOf(dbHelper.listarUsuarios()) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 24.dp, vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {

        // — Título
        Text(
            text = "Cadastro de Usuário",
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(bottom = 24.dp)
        )

        // — Campo Nome
        // OutlinedTextField exibe um campo com borda ao redor
        OutlinedTextField(
            value = nome,
            onValueChange = { nome = it }, // atualiza o estado a cada digitação
            label = { Text("Nome") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(12.dp))

        // — Campo Idade
        // keyboardType = Number exibe teclado numérico no dispositivo
        OutlinedTextField(
            value = idade,
            onValueChange = { idade = it }, // atualiza o estado a cada digitação
            label = { Text("Idade") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(20.dp))

        // — Campo E-mail
        OutlinedTextField(
            value = email,
            onValueChange = { email = it },
            label = { Text("E-mail") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        // — Botão Cadastrar
        Button(
            onClick = {
                // Validação: os dois campos precisam estar preenchidos
                if (nome.isBlank() || idade.isBlank() || email.isBlank) {
                    Toast.makeText(context, "Preencha todos os campos!", Toast.LENGTH_SHORT).show()
                    return@Button
                }

                val idadeInt = idade.toIntOrNull()
                if (idadeInt == null || idadeInt <= 0) {
                    Toast.makeText(context, "Idade inválida!", Toast.LENGTH_SHORT).show()
                    return@Button
                }

                // Chama o DatabaseHelper para inserir o registro no SQLite
                val idInserido = dbHelper.inserirUsuario(nome.trim(), idadeInt, email.trim)

                if (idInserido != -1L) {
                    // Inserção bem-sucedida: exibe confirmação e recarrega a lista
                    Toast.makeText(context, "Usuário cadastrado! ID: $idInserido", Toast.LENGTH_SHORT).show()

                    // Limpa os campos após o cadastro
                    nome  = ""
                    idade = ""
                    email = ""

                    // Atualiza o estado reativo para refletir o novo registro na lista
                    usuarios = dbHelper.listarUsuarios()
                } else {
                    Toast.makeText(context, "Erro ao cadastrar!", Toast.LENGTH_SHORT).show()
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(text = "Cadastrar", fontSize = 16.sp)
        }

        Spacer(modifier = Modifier.height(28.dp))

        // — Lista de Usuários Cadastrados
        if (usuarios.isNotEmpty()) {
            Text(
                text = "Usuários cadastrados (${usuarios.size})",
                fontWeight = FontWeight.SemiBold,
                fontSize = 16.sp,
                modifier = Modifier
                    .align(Alignment.Start)
                    .padding(bottom = 8.dp)
            )

            // LazyColumn renderiza apenas os itens visíveis (eficiente para listas longas)
            LazyColumn(modifier = Modifier.fillMaxWidth()) {
                items(usuarios) { (nomeItem, idadeItem, emailItem) ->
                    // Card para cada usuário retornado pelo SELECT
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                    ) {
                        Text(
                            text = "$nomeItem – $idadeItem anos – $emailItem",
                            modifier = Modifier.padding(12.dp),
                            fontSize = 15.sp
                        )
                    }
                }
            }
        }
    }
}