package com.example.appsqlite

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

// Constantes que definem o nome do banco, da tabela e das colunas
private const val DATABASE_NAME    = "usuarios.db"
private const val DATABASE_VERSION = 1
private const val TABLE_USUARIOS   = "usuarios"
private const val COLUNA_ID        = "id"
private const val COLUNA_NOME      = "nome"
private const val COLUNA_IDADE     = "idade"

/**
 * DatabaseHelper gerencia a criação e atualização do banco SQLite.
 * Herda de SQLiteOpenHelper, que cuida de abrir/criar o arquivo .db.
 */
class DatabaseHelper(context: Context) : SQLiteOpenHelper(
    context, DATABASE_NAME, null, DATABASE_VERSION
) {

    // Chamado automaticamente na primeira vez que o banco é acessado
    override fun onCreate(db: SQLiteDatabase) {
        // SQL que cria a tabela "usuarios" com id (chave primária autoincremento),
        // nome (texto obrigatório) e idade (inteiro obrigatório)
        val criarTabela = """
            CREATE TABLE $TABLE_USUARIOS (
                $COLUNA_ID    INTEGER PRIMARY KEY AUTOINCREMENT,
                $COLUNA_NOME  TEXT    NOT NULL,
                $COLUNA_IDADE INTEGER NOT NULL
            )
        """.trimIndent()

        // Executa o SQL de criação da tabela
        db.execSQL(criarTabela)
    }

    // Chamado quando DATABASE_VERSION é incrementado (migrações futuras)
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // Descarta a tabela antiga e recria – adequado para desenvolvimento
        db.execSQL("DROP TABLE IF EXISTS $TABLE_USUARIOS")
        onCreate(db)
    }

    /**
     * Insere um usuário no banco de dados.
     * @param nome  Nome do usuário
     * @param idade Idade do usuário
     * @return ID da linha inserida, ou -1 em caso de erro
     */
    fun inserirUsuario(nome: String, idade: Int): Long {
        // Abre o banco no modo escrita
        val db = writableDatabase

        // ContentValues é o mapa chave→valor usado para montar o INSERT
        val valores = ContentValues().apply {
            put(COLUNA_NOME, nome)   // mapeia a coluna "nome" → valor informado
            put(COLUNA_IDADE, idade) // mapeia a coluna "idade" → valor informado
        }

        // Executa INSERT INTO usuarios (nome, idade) VALUES (?, ?)
        // Retorna o rowId da linha recém-inserida
        val idInserido = db.insert(TABLE_USUARIOS, null, valores)

        // Fecha a conexão após a operação para liberar recursos
        db.close()

        return idInserido
    }

    /**
     * Retorna todos os usuários cadastrados.
     * @return Lista de pares (nome, idade)
     */
    fun listarUsuarios(): List<Pair<String, Int>> {
        val lista = mutableListOf<Pair<String, Int>>()

        // Abre o banco no modo leitura
        val db = readableDatabase

        // Executa SELECT id, nome, idade FROM usuarios
        val cursor = db.query(
            TABLE_USUARIOS,
            arrayOf(COLUNA_ID, COLUNA_NOME, COLUNA_IDADE),
            null, null, null, null, null
        )

        // Itera sobre cada linha retornada pelo cursor
        cursor.use { c ->
            while (c.moveToNext()) {
                val nome  = c.getString(c.getColumnIndexOrThrow(COLUNA_NOME))
                val idade = c.getInt(c.getColumnIndexOrThrow(COLUNA_IDADE))
                lista.add(Pair(nome, idade))
            }
        }

        db.close()
        return lista
    }
}