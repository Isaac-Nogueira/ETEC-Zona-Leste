package com.example.dice_roller

import android.media.Image
import android.os.Bundle
import android.widget.Button
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.example.dice_roller.ui.theme.Dice_RollerTheme
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.res.painterResource
import androidx.compose.foundation.Image
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.sp
import androidx.compose.material3.Button
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.material3.OutlinedTextField
import androidx.compose.foundation.text.KeyboardOptions

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            Dice_RollerTheme {
            }
            Dice_RollerApp()
        }
    }
}

@Preview(showBackground = true)
@Composable
fun Dice_RollerApp() {
    DiceWithButtonAndImage(
        modifier = Modifier
            .fillMaxSize()
            .wrapContentSize(Alignment.Center)
    )
}

@Composable
fun DiceWithButtonAndImage (modifier: Modifier = Modifier) {

    var result by remember { mutableStateOf(1) }
    var userGuess by remember { mutableStateOf("") }
    var feedbackMessage by remember { mutableStateOf("") }
    val imageResource = when (result) {
        1 -> R.drawable.dice_one
        2 -> R.drawable.dice_two
        3 -> R.drawable.dice_three
        4 -> R.drawable.dice_four
        5 -> R.drawable.dice_five
        else -> R.drawable.dice_six
    }

    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Image(
            painter = painterResource(imageResource),
            contentDescription = result.toString()
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Campo de texto
        OutlinedTextField(
            value = userGuess,
            onValueChange = { userGuess = it },
            label = { Text("Seu palpite (1-6)") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            singleLine = true
        )

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = {
                result = (1..6).random()
                val guess = userGuess.toIntOrNull()

                if (guess == null) {
                    feedbackMessage = "Digite um número primeiro!"
                } else if (guess == result) {
                    feedbackMessage = " O dado deu $result, vc acertou"
                } else {
                    feedbackMessage = " O dado deu $result"
                }
            }
        ) {
            Text(text = stringResource(id = R.string.Roll), fontSize = 24.sp)
        }

        if (feedbackMessage.isNotEmpty()) {
            Spacer(modifier = Modifier.height(16.dp))
            Text(text = feedbackMessage, fontSize = 20.sp)
        }
    }
}


